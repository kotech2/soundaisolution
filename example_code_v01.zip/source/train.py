import os
import json
import pandas as pd
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.optim as optim

from torch.utils.data import DataLoader

from Dataset import exDataset
from model import exModel

import argparse



def log_history(path, metrics):
    """
    로그 저장용 함수
    """
    if os.path.exists(path):
        with open(path, mode='a') as f:
            f.write(f'{json.dumps(metrics)}\n')
    else:
        with open(path, mode='w') as f:
            f.write(f'{json.dumps(metrics)}\n')
            
            

def pop_try_except(data, key):
    try:
        value = data.pop(key)
    except KeyError as e:
        value = None
    return value
    
 
def run_batchs(model, dataloader, loss_fn, optimizer, device, train=True):
    metrics = {}
    total_loss = 0.
    total_preds, total_labels = [], []

    if train: model.train()
    else: model.eval()
        
    for info, imgs, labels in tqdm(dataloader):
        imgs, labels = imgs.to(device), labels.to(device)

        if train: 
            optimizer.zero_grad()
            outputs = model(imgs)
        else:
            with torch.no_grad():
                outputs = model(imgs)

        preds = torch.argmax(outputs, dim=1)
        loss = loss_fn(outputs, labels)

        if train:
            loss.backward()
            optimizer.step()

        total_loss += loss
        total_preds.append(preds)
        total_labels.append(labels)

    total_loss = total_loss/len(dataloader)
    total_preds = torch.concat(total_preds)
    total_labels = torch.concat(total_labels)
    
    total_accuracy = sum(total_preds == total_labels) / len(total_preds)

    metrics['loss'] = total_loss.detach().cpu().item()
    metrics['accuracy'] = total_accuracy.detach().cpu().item()

    return metrics, preds, labels
    
    
    
def main(args):

    # Load data
    with open(args.dataset_path) as f:
        info = json.load(f)

        hyperparameter = pop_try_except(info, 'hyperparameter')
        train_set = pop_try_except(info, 'train_set')
        val_set = pop_try_except(info, 'val_set')
        
    batch_size = hyperparameter['batch']
    learning_rate = hyperparameter['lr']
    epochs = hyperparameter['epoch']

    # Prepare dataset
    train_dataset = exDataset(train_set)
    with open(os.path.join(args.model_dir, 'label_to_index.json'), mode='w') as f:
        json.dump(train_dataset.label_to_index, f, indent=4, ensure_ascii=False)
    
    val_dataset = exDataset(val_set, label_to_index=train_dataset.label_to_index)
    
    train_dataloader = DataLoader(dataset=train_dataset, batch_size=batch_size, num_workers=8, shuffle=False)
    val_dataloader = DataLoader(dataset=val_dataset, batch_size=batch_size, num_workers=8, shuffle=False)
    
    # prepare model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = exModel(train_dataset.class_num)
    model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
    # Train
    beat_accuracy = 0.
    for epoch in tqdm(range(epochs)):
        train_metrics, train_preds, train_labels = run_batchs(model, train_dataloader, criterion, optimizer, device, train=True)
        val_metrics, val_preds, val_labels = run_batchs(model, val_dataloader, criterion, optimizer, device , train=False)

        '''
        '''
        total_metrics = {'epoch': epoch, 'epochs':epochs}
        for k, v in train_metrics.items(): total_metrics[f'{k}/train'] = v
        for k, v in val_metrics.items(): total_metrics[f'{k}/val'] = v

        '''
        최고 성능 저장
        '''
        if beat_accuracy < total_metrics['accuracy/val']: 
            beat_accuracy = total_metrics['accuracy/val']
            model.save_model(os.path.join(args.model_dir, 'model.pt'))

        '''
        모델 생성 모니터링 - 진행상황을 위한 progress history
        고정경로 : /shared/models/history.log
        '''
        log_history(os.path.join(args.model_dir, 'history.log'), total_metrics)
    


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_path', default="/shared/models/dataset.json")
    parser.add_argument('--model_dir', default="/shared/models")
    
    args = parser.parse_args()
    
    main(args)


    

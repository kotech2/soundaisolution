#!/bin/bash


echo "Training Start"
python train.py \
    --dataset_path "/shared/models/dataset.json"\
    --model_dir "/shared/models"
echo "Training Done"


echo ""

echo "Evaluation Start"        
python eval.py \
    --dataset_path "/shared/models/dataset.json"\
    --model_dir "/shared/models" \
    --confusion_matrix


echo "Evaluation Start"        
python eval.py \
    --dataset_path "/shared/models/dataset_test.json"\
    --model_dir "/shared/models" \
    --output_path "/shared/models/output_test.json"

import os
import json
import numpy as np
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt

import torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, confusion_matrix, ConfusionMatrixDisplay

from Dataset import exDataset
from model import exModel

import argparse



def pop_try_except(data, key):
    try:
        value = data.pop(key)
    except KeyError as e:
        value = None
    return value

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Load Model
    with open(os.path.join(args.model_dir, 'label_to_index.json')) as f:
        label_to_index = json.load(f)
    index_to_label = dict([(v, k) for k, v in label_to_index.items()])  

    model = exModel(len(label_to_index))
    model.load_model(os.path.join(args.model_dir, 'model.pt'))
    model.to(device)
    
    # Prepare dataset
    with open(args.dataset_path) as f:
        info = json.load(f)

    hyperparameter = pop_try_except(info, 'hyperparameter')
    test_set = pop_try_except(info, 'test_set')

    batch_size = hyperparameter['batch']

    test_dataset = exDataset(test_set, label_to_index=label_to_index)
    test_dataloader = DataLoader(dataset=test_dataset, batch_size=batch_size, num_workers=8, shuffle=False)
    
    # evaluate
    total_infos = []
    total_preds = []
    model.eval()
    max_iter = len(test_dataloader)
    current_iter = 0

    for info, imgs, labels in tqdm(test_dataloader):
        imgs, labels = imgs.to(device), labels.to(device)

        with torch.no_grad():
            outputs = model(imgs)

        preds = torch.argmax(outputs, dim=1)
        total_preds.append(preds)
        total_infos.append(pd.DataFrame(info))

        current_iter += 1
        history = {'iteration':current_iter, 'iterations':max_iter}
        with open(os.path.join(args.model_dir, 'test.log'), 'a') as f:
            f.write(f'{json.dumps(history)}\n')

    total_preds = torch.concat(total_preds).cpu().tolist()
    total_infos = pd.concat(total_infos).reset_index(drop=True)
    total_infos['predict'] = list(map(lambda x : index_to_label[x], total_preds))

    total_inference = [total_infos.loc[i].to_dict() for i in range(len(total_infos))]
    
    
    labels_name = list(index_to_label.values())
    result_data = {
        'accuracy': accuracy_score(total_infos['label'], total_infos['predict']),
        'precision': precision_score(total_infos['label'], total_infos['predict'], average='weighted'),
        'recall': recall_score(total_infos['label'], total_infos['predict'], average='weighted'),
        'f1-score': f1_score(total_infos['label'], total_infos['predict'], average='weighted'),
        'confusion_matrix':{
            'array': confusion_matrix(total_infos['label'], total_infos['predict'], labels=labels_name).tolist(), 
            'y_labels': labels_name,
            'x_labels': labels_name,
        }
    }
    
    result_json = {}
    result_json['test_set'] = total_inference
    result_json['result'] = result_data
    
    with open(args.output_path, mode='w') as f:
        json.dump(result_json, f, indent=4, ensure_ascii=False)

    if args.confusion_matrix:
        plt.figure()
        disp = ConfusionMatrixDisplay(confusion_matrix=np.array(confusion_matrix(total_infos['label'], total_infos['predict'], labels=labels_name)),
                                  display_labels=labels_name)
    
        disp.plot(xticks_rotation='vertical',)
        plt.savefig(os.path.join(args.model_dir, 'confusion_matrix.png'), bbox_inches='tight', transparent=True)


    
if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_path', default="/shared/models/dataset.json")
    parser.add_argument('--model_dir', default="/shared/models")
    parser.add_argument('--output_path', default='/shared/models/output.json')
    parser.add_argument('--confusion_matrix', action='store_true')
    
    args = parser.parse_args()
    
    main(args)

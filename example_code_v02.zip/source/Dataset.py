import numpy as np

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

import torchvision.transforms as transforms

import torchaudio
from torchaudio.transforms import Spectrogram




class exDataset(Dataset):
    def __init__(self, dataset, custom_transforms=None, label_to_index=None):
        super(exDataset, self).__init__()

        n_fft = 16000
        win_len = 16000
        imgsize = 64

        self.dataset = dataset

        labels = list(map(lambda x : x['label'], dataset))
        labels, counts = np.unique(labels, return_counts=True)

        if label_to_index is None:
            self.labels = labels
            self.counts = counts
            self.index_to_label = dict(enumerate(labels))
            self.label_to_index = dict([(v, i) for i, v in enumerate(labels)])
            self.class_num = len(labels)
        else:
            self.label_to_index = label_to_index

        if custom_transforms is None:
            self.transforms = transforms.Compose([
                Spectrogram(n_fft=n_fft, win_length=win_len, power=True),
                transforms.ToPILImage(),
                transforms.Resize((imgsize*3, imgsize)),
                transforms.ToTensor(),
                transforms.Lambda(lambda x: torch.concat([x[:, :imgsize, :], x[:, imgsize:imgsize*2, :], x[:, imgsize*2:, :]])),
            ])
        else:
            self.transforms = transforms
    
    def __getitem__(self, index):
        info = self.dataset[index]
        media_url = self.dataset[index]['media_url']
        label = self.dataset[index]['label']
        label_num = self.label_to_index[label]
        
        signal, sr = torchaudio.load(media_url)
        signal, sr = F.interpolate(
            signal.unsqueeze(0),
            scale_factor=16000/sr, mode='linear').squeeze(0), 16000

        signal_img = self.transforms(signal)
        
        return info, signal_img, label_num

    def __len__(self):
        return len(self.dataset)

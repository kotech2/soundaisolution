import torch
import torch.nn as nn

import torchvision.models


class exModel(nn.Module):
    def __init__(self, class_num):
        super(exModel, self).__init__()
        self.model = torchvision.models.resnet50(pretrained = False)
        self.model.fc = nn.Linear(self.model.fc.in_features, class_num)

    def to(self, device):
        self.model = self.model.to(device)

    def parameters(self):
        return self.model.parameters()

    def forward(self, x):
        return self.model(x)

    def save_model(self, path):
        torch.save(self.model.state_dict(), path)

    def load_model(self, path):
        self.model.load_state_dict(torch.load(path, weights_only=True))
